// ================================
// Define which key plays which animal sound
// ================================
const animalSounds = {
  'a': 'lion.mp3',
  's': 'monkey.mp3',
  'd': 'elephant.mp3',
  'f': 'frog.mp3',
  'g': 'bird.mp3',
  'h': 'snake.mp3',
  'j': 'tiger.mp3'
};

// ================================
// Define how the animal name should be shown on screen (with emoji)
// ================================
const animalNames = {
  'a': '🦁 Lion',
  's': '🐒 Monkey',
  'd': '🐘 Elephant',
  'f': '🐸 Frog',
  'g': '🐦 Bird',
  'h': '🐍 Snake',
  'j': '🐯 Tiger'
};

// ================================
// This function plays the correct animal sound when a key is pressed or an image is clicked
// It also makes the animal "jump" (scale animation) and updates the last animal clicked
// ================================
function playAnimalSound(key) {
  const soundFile = animalSounds[key];
  if (soundFile) {
    const audio = new Audio(`sounds/${soundFile}`); // create a sound object
    audio.play(); // play the sound
    flashAnimal(key); // make the animal jump
    updateLastClickedAnimal(key); // store and show last clicked
  }
}

// ===== New Feature (Not taught in class) =====
// This function saves the last clicked animal into localStorage,
// and updates the screen to show it even after refreshing the page
// ================================
function updateLastClickedAnimal(key) {
  localStorage.setItem("lastAnimal", key); // save in browser storage
  const display = document.getElementById("last-animal-display");
  if (display && animalNames[key]) {
    display.textContent = `Last animal you clicked: ${animalNames[key]}`;
  }
}

// ================================
// This adds a quick zoom effect to the animal when it's clicked
// ================================
function flashAnimal(key) {
  const animalElement = document.querySelector(`.animal[data-key="${key}"]`);
  if (animalElement) {
    animalElement.style.transform = "scale(1.2)";
    setTimeout(() => {
      animalElement.style.transform = "scale(1)";
    }, 150);
  }
}

// ================================
// This listens for mouse clicks on animal images
// ================================
const animals = document.querySelectorAll(".animal");
animals.forEach(animal => {
  animal.addEventListener("click", () => {
    const key = animal.getAttribute("data-key");
    playAnimalSound(key);
  });
});

// ================================
// This listens for keyboard key presses
// ================================
document.addEventListener("keydown", (event) => {
  const key = event.key.toLowerCase();
  playAnimalSound(key);
});

// ================================
// This runs once the page is fully loaded
// It creates the display for the last clicked animal
// and tries to autoplay background music
// ================================
document.addEventListener("DOMContentLoaded", () => {
  const lastAnimal = localStorage.getItem("lastAnimal"); // get last clicked from storage

  // Create a new element in the page to show the last animal
  const display = document.createElement("div");
  display.id = "last-animal-display";
  display.style.color = "white";
  display.style.fontSize = "1.2em";
  display.style.marginTop = "20px";
  display.style.textShadow = "1px 1px 2px black";
  document.body.appendChild(display);

  if (lastAnimal && animalNames[lastAnimal]) {
    display.textContent = `Last animal you clicked: ${animalNames[lastAnimal]}`;
  }

  // ================================
  // Try to play background music automatically
  // If browser blocks autoplay, show a clickable message
  // ================================
  const bgMusic = document.getElementById("background-music");
  if (bgMusic) {
    bgMusic.muted = false;
    bgMusic.play().catch(() => {
      // show user a tip to click
      const tip = document.createElement("div");
      tip.innerText = "Click anywhere to play background music";
      tip.style.position = "fixed";
      tip.style.bottom = "20px";
      tip.style.left = "50%";
      tip.style.transform = "translateX(-50%)";
      tip.style.background = "rgba(0,0,0,0.7)";
      tip.style.color = "white";
      tip.style.padding = "10px 20px";
      tip.style.borderRadius = "10px";
      tip.style.fontSize = "1em";
      tip.style.zIndex = "1000";
      document.body.appendChild(tip);

      // once user clicks, play music and remove the message
      document.addEventListener("click", () => {
        bgMusic.play();
        tip.remove();
      }, { once: true });
    });
  }
});
